#!/usr/bin/env python3
"""
Out-of-order (n-gram) accuracy benchmark for nl2lldb.

Every case here is a natural-language request whose words are deliberately
shuffled or reordered, to exercise the order-independent matching layer.
Reports exact-match accuracy, validity, and the misses, just like the main
benchmark.  Uses the deterministic static backend.

    python3 benchmark_ngram_nl2lldb.py
    python3 benchmark_ngram_nl2lldb.py --misses
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from typing import List, Tuple

import nl2lldb
from nl2lldb import StaticBackend, Validator, make_translator

T = make_translator(force_static=True)
BACKEND = StaticBackend()
_V = Validator(BACKEND)

# (category, scrambled natural language, expected command)
DATASET: List[Tuple[str, str, str]] = [
    # --- breakpoints (words reordered) ---
    ("bp", "main breakpoint set", "breakpoint set --name main"),
    ("bp", "at main set breakpoint", "breakpoint set --name main"),
    ("bp", "breakpoint main at a set", "breakpoint set --name main"),
    ("bp", "handle_request a breakpoint put at", "breakpoint set --name handle_request"),
    ("bp", "0x400500 breakpoint at set", "breakpoint set --address 0x400500"),
    ("bp", "breakpoints list all", "breakpoint list"),
    ("bp", "breakpoints show", "breakpoint list"),
    ("bp", "2 breakpoint delete", "breakpoint delete 2"),
    ("bp", "breakpoint 3 disable", "breakpoint disable 3"),
    ("bp", "4 enable breakpoint", "breakpoint enable 4"),
    # --- run control ---
    ("run", "program the run", "process launch"),
    ("run", "the launch program", "process launch"),
    ("run", "execution continue", "process continue"),
    ("run", "going keep", "process continue"),
    ("run", "process the kill", "process kill"),
    ("run", "the process interrupt", "process interrupt"),
    ("run", "process from the detach", "process detach"),
    # --- stepping (reordered) ---
    ("step", "over step", "thread step-over"),
    ("step", "in step", "thread step-in"),
    ("step", "out step", "thread step-out"),
    ("step", "instruction one step", "thread step-inst"),
    # --- threads / frames ---
    ("thr", "threads list", "thread list"),
    ("thr", "3 thread select", "thread select 3"),
    ("thr", "2 frame select", "frame select 2"),
    ("thr", "variables local show", "frame variable"),
    ("thr", "backtrace a show", "thread backtrace"),
    # --- expression / print ---
    ("expr", "result print", "expression -- result"),
    ("expr", "self po", "expression -O -- self"),
    # --- registers / memory ---
    ("reg", "rax register read", "register read rax"),
    ("reg", "registers all read", "register read --all"),
    ("mem", "0x1000 at memory read", "memory read 0x1000"),
    ("mem", "memory 0x4000 at the dump", "memory read 0x4000"),
    # --- watchpoints ---
    ("watch", "counter variable the watch", "watchpoint set variable counter"),
    ("watch", "watchpoints list", "watchpoint list"),
    ("watch", "1 watchpoint delete", "watchpoint delete 1"),
    # --- disassembly / source ---
    ("disas", "main disassemble", "disassemble --name main"),
    ("disas", "source the list", "source list"),
    # --- attach / images ---
    ("attach", "1234 pid to attach", "process attach --pid 1234"),
    ("image", "modules loaded list", "target modules list"),
    ("image", "malloc symbol look up", "target modules lookup --name malloc"),
    # --- settings / misc ---
    ("settings", "settings show", "settings show"),
    ("misc", "version lldb show", "version"),
    ("misc", "gui the open", "gui"),
    ("misc", "lldb quit", "quit"),
]


def _valid(command: str) -> bool:
    if not command:
        return False
    path, _ = _V.command_path(command)
    return bool(path) and BACKEND.command_exists(path)


def run():
    rows = []
    for category, text, expected in DATASET:
        t = T.translate(text)
        got = t.command or ""
        rows.append({"category": category, "input": text, "expected": expected,
                     "got": got, "correct": got == expected, "valid": _valid(got),
                     "intent": t.intent})
    return rows


def main(argv=None):
    p = argparse.ArgumentParser(description="Out-of-order accuracy benchmark.")
    p.add_argument("--misses", action="store_true", help="show only the misses")
    args = p.parse_args(argv)

    rows = run()
    total = len(rows)
    correct = sum(r["correct"] for r in rows)
    valid = sum(r["valid"] for r in rows)
    by_cat = defaultdict(lambda: [0, 0])
    for r in rows:
        by_cat[r["category"]][1] += 1
        if r["correct"]:
            by_cat[r["category"]][0] += 1

    if not args.misses:
        print("=" * 70)
        print("nl2lldb OUT-OF-ORDER (n-gram) ACCURACY BENCHMARK")
        print("=" * 70)
        print("dataset size         : %d scrambled cases" % total)
        print("EXACT-MATCH ACCURACY : %d/%d = %.1f%%" % (correct, total, 100 * correct / total))
        print("COMMAND VALIDITY     : %d/%d = %.1f%%" % (valid, total, 100 * valid / total))
        print("-" * 70)
        for cat, (c, n) in sorted(by_cat.items()):
            print("  %-10s %d/%d" % (cat, c, n))
        print("-" * 70)

    misses = [r for r in rows if not r["correct"]]
    if misses:
        print("\nMISSES (%d):" % len(misses))
        for r in misses:
            print("  [%s] %r" % (r["category"], r["input"]))
            print("        expected: %s" % r["expected"])
            print("        got:      %s  (intent=%s)" % (r["got"] or "(none)", r["intent"]))
    else:
        print("\nMISSES: none -- 100%% exact match on scrambled input.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
