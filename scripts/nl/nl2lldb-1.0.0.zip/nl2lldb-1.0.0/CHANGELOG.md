# Changelog

## 1.0.0

First stable release.

- Natural-language to LLDB command translation covering the full standard
  command set (all top-level commands and sub-commands), emitting canonical
  (non-alias) commands.
- Validation against the live LLDB command interpreter when available
  (`SBCommandInterpreter.CommandExists` / `HandleCompletion` / `help`), with a
  bundled command-tree backend as a dependency-free fallback.
- Order-independent (n-gram) matching: a regex-to-slots compiler lets each
  intent match its words in any order, gated behind strong in-order phrases so
  precise behaviour is preserved; idf weighting favours discriminative words.
- Order-independent argument extraction (function/variable/register names,
  file:line, address, pid, conditions, expressions), with a controlled command
  vocabulary so command words are never mistaken for identifiers.
- Partial-input handling: recognised-but-underspecified requests return the
  partial command plus completion suggestions.
- Guarantee: whenever a complete, valid command cannot be formed, actionable
  suggestions are always returned (sub-commands, completions, or closest
  commands).
- Per-translator LRU caching of results and backend lookups.
- CLI (`nl2lldb`) with `--json`, `--verbose/-v`, `--static`, `--demo`,
  `--version`; reads positional text or stdin.
- 61 unit tests; in-order accuracy 176/176 (100%), scrambled accuracy 44/44
  (100%), command validity 100%.
