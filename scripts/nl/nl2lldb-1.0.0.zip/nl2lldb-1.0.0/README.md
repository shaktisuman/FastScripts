# nl2lldb

Translate natural-language English into valid **LLDB** debugger commands.

```console
$ nl2lldb "set a breakpoint at main"
breakpoint set --name main

$ nl2lldb "main breakpoint set"      # words may be out of order
breakpoint set --name main

$ nl2lldb "read 16 bytes at 0x1000"
memory read --count 16 0x1000
```

- **Full command coverage** — every standard LLDB top-level command and sub-command.
- **Canonical, validated output** — emits the canonical command (never an alias) and
  validates its command path against LLDB itself when available, or a bundled
  command tree otherwise.
- **Order-independent** — an n-gram layer understands scrambled word order.
- **Always actionable** — when a complete, valid command can't be formed, it returns
  suggestions (sub-commands, completions, or the closest commands).
- **Zero dependencies** — Python 3.8+, standard library only. LLDB optional.

## Install

```console
pip install .          # provides the `nl2lldb` command and an importable module
# or just run it:
python3 nl2lldb.py "step over"
```

## Python

```python
from nl2lldb import make_translator
t = make_translator()
print(t.translate("step over").command)   # 'thread step-over'
```

## Test & benchmark

```console
python3 test_nl2lldb.py            # 61 tests
python3 benchmark_nl2lldb.py       # in-order accuracy: 176/176 (100%)
python3 benchmark_ngram_nl2lldb.py # scrambled accuracy: 44/44 (100%)
```

See **[HOW_TO_USE.txt](HOW_TO_USE.txt)** for the complete guide. MIT licensed.
