#!/usr/bin/env python3
"""
Accuracy benchmark for nl2lldb.

Runs a large, hand-labeled dataset of natural-language debugging requests
through the translator and reports:

  * overall exact-match accuracy (emitted command == expected command),
  * command-validity rate (does the emitted command's path exist in LLDB's
    command tree?),
  * a per-category accuracy breakdown,
  * mean confidence on correct vs. incorrect outputs,
  * a full listing of every miss (input / expected / got).

Uses the deterministic static backend so the numbers are reproducible on any
machine, with or without LLDB installed.

    python3 benchmark_nl2lldb.py            # full report
    python3 benchmark_nl2lldb.py --misses   # only the misses
    python3 benchmark_nl2lldb.py --json      # machine-readable summary
"""

from __future__ import annotations

import argparse
import json
import sys
from collections import defaultdict
from typing import List, Tuple

import nl2lldb
from nl2lldb import StaticBackend, Validator, make_translator

T = make_translator(force_static=True)
BACKEND = StaticBackend()
_V = Validator(BACKEND)

# (category, natural_language_input, expected_canonical_command)
DATASET: List[Tuple[str, str, str]] = [
    # ============================ breakpoint: set ============================
    ("bp.set", "set a breakpoint at main", "breakpoint set --name main"),
    ("bp.set", "set breakpoint at main", "breakpoint set --name main"),
    ("bp.set", "break at main", "breakpoint set --name main"),
    ("bp.set", "break main", "breakpoint set --name main"),
    ("bp.set", "add a breakpoint in handle_request", "breakpoint set --name handle_request"),
    ("bp.set", "put a breakpoint on foo", "breakpoint set --name foo"),
    ("bp.set", "create a breakpoint at Server::run", "breakpoint set --name Server::run"),
    ("bp.set", "insert a breakpoint at _start", "breakpoint set --name _start"),
    ("bp.set", "break at foo.c:42", "breakpoint set --file foo.c --line 42"),
    ("bp.set", "set a breakpoint at file parser.cpp line 88",
     "breakpoint set --file parser.cpp --line 88"),
    ("bp.set", "break at line 25", "breakpoint set --line 25"),
    ("bp.set", "put a breakpoint at line 100", "breakpoint set --line 100"),
    ("bp.set", "set a breakpoint at address 0x4005f0", "breakpoint set --address 0x4005f0"),
    ("bp.set", "add a breakpoint at 0x400500", "breakpoint set --address 0x400500"),
    ("bp.set", "set a temporary breakpoint at main", "breakpoint set --name main --one-shot true"),
    ("bp.set", "set a one-shot breakpoint at cleanup",
     "breakpoint set --name cleanup --one-shot true"),
    ("bp.set", "put a temporary breakpoint at line 88 of parser.cpp",
     "breakpoint set --file parser.cpp --line 88 --one-shot true"),
    ("bp.set", "stop at parse", "breakpoint set --name parse"),
    ("bp.set", "set a conditional breakpoint at foo if x == 5",
     "breakpoint set --name foo --condition 'x == 5'"),
    ("bp.set", "break at process_request when retries > 3",
     "breakpoint set --name process_request --condition 'retries > 3'"),
    ("bp.set", "stop at line 50 if i > 100",
     "breakpoint set --line 50 --condition 'i > 100'"),

    # ====================== breakpoint: list/del/en/dis ======================
    ("bp.manage", "list breakpoints", "breakpoint list"),
    ("bp.manage", "show all breakpoints", "breakpoint list"),
    ("bp.manage", "show me the breakpoints", "breakpoint list"),
    ("bp.manage", "what breakpoints are set", "breakpoint list"),
    ("bp.manage", "display breakpoints", "breakpoint list"),
    ("bp.manage", "delete breakpoint 2", "breakpoint delete 2"),
    ("bp.manage", "remove breakpoint 5", "breakpoint delete 5"),
    ("bp.manage", "clear breakpoint 7", "breakpoint delete 7"),
    ("bp.manage", "delete all breakpoints", "breakpoint delete"),
    ("bp.manage", "remove all breakpoints", "breakpoint delete"),
    ("bp.manage", "disable breakpoint 3", "breakpoint disable 3"),
    ("bp.manage", "turn off breakpoint 1", "breakpoint disable 1"),
    ("bp.manage", "enable breakpoint 4", "breakpoint enable 4"),
    ("bp.manage", "turn on breakpoint 2", "breakpoint enable 2"),
    ("bp.manage", "disable all breakpoints", "breakpoint disable"),
    ("bp.manage", "ignore breakpoint 1 for 5 hits", "breakpoint modify --ignore-count 5 1"),
    ("bp.manage", "skip breakpoint 3 the next 10 times", "breakpoint modify --ignore-count 10 3"),

    # ============================ run control ===============================
    ("run", "run the program", "process launch"),
    ("run", "launch the program", "process launch"),
    ("run", "start the executable", "process launch"),
    ("run", "launch the program with args foo bar", "process launch -- foo bar"),
    ("run", "run with arguments --verbose input.txt", "process launch -- --verbose input.txt"),
    ("run", "run and stop at the entry point", "process launch --stop-at-entry"),
    ("run", "continue", "process continue"),
    ("run", "continue execution", "process continue"),
    ("run", "resume", "process continue"),
    ("run", "keep going", "process continue"),
    ("run", "carry on", "process continue"),
    ("run", "interrupt the process", "process interrupt"),
    ("run", "pause the process", "process interrupt"),
    ("run", "kill the process", "process kill"),
    ("run", "terminate the program", "process kill"),
    ("run", "detach from the process", "process detach"),
    ("run", "is the program running", "process status"),
    ("run", "what is the process status", "process status"),

    # ============================== stepping ================================
    ("step", "step over", "thread step-over"),
    ("step", "next", "thread step-over"),
    ("step", "next line", "thread step-over"),
    ("step", "step to the next line", "thread step-over"),
    ("step", "go over the next line", "thread step-over"),
    ("step", "step into", "thread step-in"),
    ("step", "step in", "thread step-in"),
    ("step", "step into the function", "thread step-in"),
    ("step", "step out", "thread step-out"),
    ("step", "finish", "thread step-out"),
    ("step", "step out of the function", "thread step-out"),
    ("step", "return from the current function", "thread step-out"),
    ("step", "next instruction", "thread step-inst-over"),
    ("step", "step over one instruction", "thread step-inst-over"),
    ("step", "step one instruction", "thread step-inst"),
    ("step", "single step", "thread step-inst"),
    ("step", "step a single instruction", "thread step-inst"),
    ("step", "run until line 50", "thread until 50"),
    ("step", "continue until line 200", "thread until 200"),

    # =========================== threads / frames ===========================
    ("thr_frame", "show a backtrace", "thread backtrace"),
    ("thr_frame", "backtrace", "thread backtrace"),
    ("thr_frame", "bt", "thread backtrace"),
    ("thr_frame", "print a backtrace", "thread backtrace"),
    ("thr_frame", "show the call stack", "thread backtrace"),
    ("thr_frame", "show the stack trace", "thread backtrace"),
    ("thr_frame", "backtrace all threads", "thread backtrace --all"),
    ("thr_frame", "list threads", "thread list"),
    ("thr_frame", "show all threads", "thread list"),
    ("thr_frame", "show me the threads", "thread list"),
    ("thr_frame", "select thread 3", "thread select 3"),
    ("thr_frame", "switch to thread 2", "thread select 2"),
    ("thr_frame", "thread info", "thread info"),
    ("thr_frame", "select frame 2", "frame select 2"),
    ("thr_frame", "go to frame 0", "frame select 0"),
    ("thr_frame", "switch to frame 4", "frame select 4"),
    ("thr_frame", "go up one frame", "frame select --relative 1"),
    ("thr_frame", "move up a frame", "frame select --relative 1"),
    ("thr_frame", "go down one frame", "frame select --relative -1"),
    ("thr_frame", "frame info", "frame info"),
    ("thr_frame", "where am I", "frame info"),
    ("thr_frame", "show the current frame", "frame info"),
    ("thr_frame", "what line am I on", "frame info"),
    ("thr_frame", "show local variables", "frame variable"),
    ("thr_frame", "list locals", "frame variable"),
    ("thr_frame", "print all local variables", "frame variable"),

    # ========================= expressions / print ==========================
    ("expr", "print x", "expression -- x"),
    ("expr", "print myVar", "expression -- myVar"),
    ("expr", "print the value of counter", "expression -- counter"),
    ("expr", "print myStruct->count + 1", "expression -- myStruct->count + 1"),
    ("expr", "evaluate a + b", "expression -- a + b"),
    ("expr", "what is the value of x", "expression -- x"),
    ("expr", "compute n * 2", "expression -- n * 2"),
    ("expr", "po self", "expression -O -- self"),
    ("expr", "po myObject", "expression -O -- myObject"),
    ("expr", "print object request", "expression -O -- request"),
    ("expr", "describe object view", "expression -O -- view"),

    # ============================== registers ===============================
    ("reg", "read register rax", "register read rax"),
    ("reg", "show register rdi", "register read rdi"),
    ("reg", "read the rsp register", "register read rsp"),
    ("reg", "dump all registers", "register read --all"),
    ("reg", "read all registers", "register read --all"),
    ("reg", "set register rax to 0x10", "register write rax 0x10"),
    ("reg", "set rax to 5", "register write rax 5"),
    ("reg", "write 0xdead to register rsi", "register write rsi 0xdead"),

    # =============================== memory =================================
    ("mem", "read memory at 0x1000", "memory read 0x1000"),
    ("mem", "show me the memory at 0x4000", "memory read 0x4000"),
    ("mem", "dump memory at 0xabcd", "memory read 0xabcd"),
    ("mem", "examine 64 bytes at 0x2000", "memory read --count 64 0x2000"),
    ("mem", "read 16 bytes of memory at 0x2000", "memory read --count 16 0x2000"),
    ("mem", "read 8 bytes at 0x10", "memory read --count 8 0x10"),
    ("mem", "write 0xff to address 0x3000", "memory write 0x3000 0xff"),
    ("mem", "write 0x90 to 0x1000", "memory write 0x1000 0x90"),

    # ============================= watchpoints ==============================
    ("watch", "watch counter", "watchpoint set variable counter"),
    ("watch", "watch the variable counter", "watchpoint set variable counter"),
    ("watch", "set a watchpoint on myvar", "watchpoint set variable myvar"),
    ("watch", "set a watchpoint on the variable total", "watchpoint set variable total"),
    ("watch", "list watchpoints", "watchpoint list"),
    ("watch", "delete watchpoint 1", "watchpoint delete 1"),
    ("watch", "delete all watchpoints", "watchpoint delete"),

    # ============================ disassembly ===============================
    ("disas", "disassemble", "disassemble"),
    ("disas", "disassemble main", "disassemble --name main"),
    ("disas", "disassemble foo", "disassemble --name foo"),
    ("disas", "disassemble the current frame", "disassemble --frame"),
    ("disas", "disassemble at 0x400500", "disassemble --start-address 0x400500"),
    ("disas", "show the assembly", "disassemble"),

    # =============================== source =================================
    ("source", "list the source", "source list"),
    ("source", "show the source", "source list"),
    ("source", "list source at line 20", "source list --line 20"),
    ("source", "list source around line 10 of main.c", "source list --file main.c --line 10"),

    # =============================== attach =================================
    ("attach", "attach to pid 1234", "process attach --pid 1234"),
    ("attach", "attach to process 5678", "process attach --pid 5678"),
    ("attach", "attach to the process named server", "process attach --name server"),
    ("attach", "attach to program called worker", "process attach --name worker"),

    # =============================== images =================================
    ("image", "look up symbol malloc", "target modules lookup --name malloc"),
    ("image", "look up the symbol pthread_create", "target modules lookup --name pthread_create"),
    ("image", "look up the address 0x4000", "target modules lookup --address 0x4000"),
    ("image", "list modules", "target modules list"),
    ("image", "list loaded modules", "target modules list"),
    ("image", "show loaded images", "target modules list"),
    ("image", "list shared libraries", "target modules list"),

    # ============================== settings ================================
    ("settings", "show settings", "settings show"),
    ("settings", "show current settings", "settings show"),
    ("settings", "set setting target.run-args to --debug", "settings set target.run-args --debug"),
    ("settings", "change setting target.x86-disassembly-flavor to intel",
     "settings set target.x86-disassembly-flavor intel"),
    ("settings", "show the setting target.run-args", "settings show target.run-args"),

    # =========================== help / apropos =============================
    ("help", "help", "help"),
    ("help", "help breakpoint set", "help breakpoint set"),
    ("help", "how do I use watchpoint set", "help watchpoint set"),
    ("help", "show help for memory read", "help memory read"),
    ("help", "apropos breakpoint", "apropos breakpoint"),
    ("help", "search the help for thread", "apropos thread"),
    ("help", "find commands about memory", "apropos memory"),

    # ================================ misc ==================================
    ("misc", "show lldb version", "version"),
    ("misc", "what version is this", "version"),
    ("misc", "open the gui", "gui"),
    ("misc", "start the gui", "gui"),
    ("misc", "quit", "quit"),
    ("misc", "exit", "quit"),
    ("misc", "quit lldb", "quit"),
    ("misc", "exit the debugger", "quit"),
]


def _valid(command: str) -> bool:
    if not command:
        return False
    path, _ = _V.command_path(command)
    return bool(path) and BACKEND.command_exists(path)


def run():
    rows = []
    for category, text, expected in DATASET:
        t = T.translate(text)
        got = t.command or ""
        rows.append({
            "category": category, "input": text, "expected": expected,
            "got": got, "correct": got == expected, "valid": _valid(got),
            "intent": t.intent, "confidence": t.confidence,
        })
    return rows


def summarize(rows):
    total = len(rows)
    correct = sum(r["correct"] for r in rows)
    valid = sum(r["valid"] for r in rows)

    by_cat = defaultdict(lambda: [0, 0])
    for r in rows:
        by_cat[r["category"]][1] += 1
        if r["correct"]:
            by_cat[r["category"]][0] += 1

    conf_ok = [r["confidence"] for r in rows if r["correct"]]
    conf_bad = [r["confidence"] for r in rows if not r["correct"]]

    return {
        "total": total,
        "correct": correct,
        "accuracy": correct / total if total else 0.0,
        "valid": valid,
        "validity_rate": valid / total if total else 0.0,
        "by_category": {k: {"correct": v[0], "total": v[1],
                            "accuracy": v[0] / v[1] if v[1] else 0.0}
                        for k, v in sorted(by_cat.items())},
        "mean_conf_correct": sum(conf_ok) / len(conf_ok) if conf_ok else 0.0,
        "mean_conf_incorrect": sum(conf_bad) / len(conf_bad) if conf_bad else 0.0,
    }


def _bar(frac, width=24):
    filled = int(round(frac * width))
    return "#" * filled + "-" * (width - filled)


def print_report(rows, summary, misses_only=False):
    if not misses_only:
        print("=" * 70)
        print("nl2lldb ACCURACY BENCHMARK")
        print("=" * 70)
        print("dataset size      : %d labeled cases" % summary["total"])
        print("backend           : static command tree (deterministic)")
        print()
        print("EXACT-MATCH ACCURACY : %d/%d = %.1f%%  [%s]" % (
            summary["correct"], summary["total"],
            100 * summary["accuracy"], _bar(summary["accuracy"])))
        print("COMMAND VALIDITY     : %d/%d = %.1f%%  [%s]" % (
            summary["valid"], summary["total"],
            100 * summary["validity_rate"], _bar(summary["validity_rate"])))
        print()
        print("mean confidence  correct: %.2f   incorrect: %.2f" % (
            summary["mean_conf_correct"], summary["mean_conf_incorrect"]))
        print()
        print("-" * 70)
        print("PER-CATEGORY ACCURACY")
        print("-" * 70)
        print("%-12s %8s   %s" % ("category", "score", "accuracy"))
        for cat, s in summary["by_category"].items():
            print("%-12s %4d/%-3d   %5.1f%%  [%s]" % (
                cat, s["correct"], s["total"], 100 * s["accuracy"],
                _bar(s["accuracy"], 18)))
        print("-" * 70)

    misses = [r for r in rows if not r["correct"]]
    print()
    if misses:
        print("MISSES (%d):" % len(misses))
        for r in misses:
            print("  [%s] %r" % (r["category"], r["input"]))
            print("        expected: %s" % r["expected"])
            print("        got:      %s  (intent=%s)" % (r["got"] or "(none)", r["intent"]))
    else:
        print("MISSES: none -- 100%% exact match across all %d cases." % summary["total"])


def main(argv=None):
    p = argparse.ArgumentParser(description="Accuracy benchmark for nl2lldb.")
    p.add_argument("--misses", action="store_true", help="show only the misses")
    p.add_argument("--json", action="store_true", help="emit a JSON summary")
    args = p.parse_args(argv)

    rows = run()
    summary = summarize(rows)

    if args.json:
        print(json.dumps(summary, indent=2))
        return 0

    print_report(rows, summary, misses_only=args.misses)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
