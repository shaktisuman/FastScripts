#!/usr/bin/env python3
"""
Test suite for nl2lldb.

Runs WITHOUT any third-party dependency:

    python3 test_nl2lldb.py          # built-in runner, prints PASS/FAIL tally

...and is also compatible with pytest if you have it:

    pytest test_nl2lldb.py

All tests force the bundled static backend so results are deterministic and do
not depend on whether LLDB is installed on the machine running the tests.
"""

from __future__ import annotations

import time
import traceback
from typing import List, Tuple

import nl2lldb
from nl2lldb import (
    COMMAND_TREE, StaticBackend, Validator, extract, make_translator,
)

# A single shared translator using the deterministic static backend.
T = make_translator(force_static=True)
BACKEND = StaticBackend()


def tr(text: str) -> str:
    """Translate and return just the command string (or '' if none)."""
    return T.translate(text).command or ""


# ---------------------------------------------------------------------------
# 1. Exact natural-language -> command mappings across all common operations.
# ---------------------------------------------------------------------------
EXACT_CASES: List[Tuple[str, str]] = [
    # --- breakpoint set (function / file:line / line / address / qualifiers) ---
    ("set a breakpoint at main", "breakpoint set --name main"),
    ("set a breakpoint at MyClass::run", "breakpoint set --name MyClass::run"),
    ("break at foo.c:42", "breakpoint set --file foo.c --line 42"),
    ("put a breakpoint at line 100", "breakpoint set --line 100"),
    ("add a breakpoint at 0x400500", "breakpoint set --address 0x400500"),
    ("set a temporary breakpoint at main", "breakpoint set --name main --one-shot true"),
    ("set a conditional breakpoint at foo if x == 5",
     "breakpoint set --name foo --condition 'x == 5'"),
    ("put a temporary breakpoint at line 88 of parser.cpp",
     "breakpoint set --file parser.cpp --line 88 --one-shot true"),
    # --- breakpoint list / delete / enable / disable / ignore ---
    ("list breakpoints", "breakpoint list"),
    ("show all breakpoints", "breakpoint list"),
    ("delete breakpoint 2", "breakpoint delete 2"),
    ("remove breakpoint 5", "breakpoint delete 5"),
    ("delete all breakpoints", "breakpoint delete"),
    ("disable breakpoint 3", "breakpoint disable 3"),
    ("enable breakpoint 4", "breakpoint enable 4"),
    ("disable all breakpoints", "breakpoint disable"),
    ("ignore breakpoint 1 for 5 hits", "breakpoint modify --ignore-count 5 1"),
    # --- run control ---
    ("run the program", "process launch"),
    ("launch the program with args foo bar", "process launch -- foo bar"),
    ("run and stop at the entry point", "process launch --stop-at-entry"),
    ("continue", "process continue"),
    ("resume execution", "process continue"),
    ("keep going", "process continue"),
    ("interrupt the process", "process interrupt"),
    ("kill the process", "process kill"),
    ("detach from the process", "process detach"),
    ("what is the process status", "process status"),
    # --- stepping ---
    ("step over", "thread step-over"),
    ("next", "thread step-over"),
    ("next line", "thread step-over"),
    ("step into", "thread step-in"),
    ("step in", "thread step-in"),
    ("step out", "thread step-out"),
    ("finish", "thread step-out"),
    ("step out of the function", "thread step-out"),
    ("next instruction", "thread step-inst-over"),
    ("step one instruction", "thread step-inst"),
    ("single step", "thread step-inst"),
    ("run until line 50", "thread until 50"),
    # --- threads / frames ---
    ("show a backtrace", "thread backtrace"),
    ("backtrace", "thread backtrace"),
    ("show the call stack", "thread backtrace"),
    ("backtrace all threads", "thread backtrace --all"),
    ("list threads", "thread list"),
    ("show all threads", "thread list"),
    ("select thread 3", "thread select 3"),
    ("switch to thread 2", "thread select 2"),
    ("select frame 2", "frame select 2"),
    ("go up one frame", "frame select --relative 1"),
    ("go down one frame", "frame select --relative -1"),
    ("frame info", "frame info"),
    ("where am I", "frame info"),
    ("show local variables", "frame variable"),
    ("list locals", "frame variable"),
    # --- expressions / printing ---
    ("print the value of x", "expression -- x"),
    ("print myVar", "expression -- myVar"),
    ("print myStruct->count + 1", "expression -- myStruct->count + 1"),
    ("evaluate x + y", "expression -- x + y"),
    ("po self", "expression -O -- self"),
    ("print object self", "expression -O -- self"),
    # --- registers / memory ---
    ("read register rax", "register read rax"),
    ("show all registers", "register read --all"),
    ("read all registers", "register read --all"),
    ("set register rax to 0x10", "register write rax 0x10"),
    ("write 0x5 to register rbx", "register write rbx 0x5"),
    ("read memory at 0x1000", "memory read 0x1000"),
    ("read 16 bytes of memory at 0x2000", "memory read --count 16 0x2000"),
    ("examine memory at 0x4000", "memory read 0x4000"),
    ("write 0xff to address 0x3000", "memory write 0x3000 0xff"),
    # --- watchpoints ---
    ("watch the variable counter", "watchpoint set variable counter"),
    ("set a watchpoint on myvar", "watchpoint set variable myvar"),
    ("list watchpoints", "watchpoint list"),
    ("delete watchpoint 1", "watchpoint delete 1"),
    ("delete all watchpoints", "watchpoint delete"),
    # --- disassembly / source ---
    ("disassemble", "disassemble"),
    ("disassemble foo", "disassemble --name foo"),
    ("disassemble the current frame", "disassemble --frame"),
    ("list source around line 10 of main.c", "source list --file main.c --line 10"),
    # --- attach / images ---
    ("attach to pid 1234", "process attach --pid 1234"),
    ("attach to process named myapp", "process attach --name myapp"),
    ("look up the symbol malloc", "target modules lookup --name malloc"),
    ("list loaded modules", "target modules list"),
    ("show shared libraries", "target modules list"),
    # --- settings / misc ---
    ("show settings", "settings show"),
    ("set setting target.run-args to --debug", "settings set target.run-args --debug"),
    ("help", "help"),
    ("help breakpoint set", "help breakpoint set"),
    ("search the help for watchpoint", "apropos watchpoint"),
    ("show lldb version", "version"),
    ("open the gui", "gui"),
    ("quit", "quit"),
    ("exit the debugger", "quit"),
]


def test_exact_translations():
    failures = []
    for text, expected in EXACT_CASES:
        got = tr(text)
        if got != expected:
            failures.append("  %-48r\n      expected: %s\n      got:      %s"
                            % (text, expected, got or "(none)"))
    assert not failures, "%d exact-translation mismatch(es):\n%s" % (
        len(failures), "\n".join(failures))


# ---------------------------------------------------------------------------
# 2. Every emitted command must validate against the static command tree.
# ---------------------------------------------------------------------------
def _command_path_is_valid(command: str) -> bool:
    """The leading command words (before options/args) form a real command."""
    v = Validator(BACKEND)
    path, _consumed = v.command_path(command)
    return bool(path) and BACKEND.command_exists(path)


def test_every_emitted_command_validates():
    bad = []
    for text, _ in EXACT_CASES:
        cmd = tr(text)
        if not cmd:
            bad.append("%r produced no command" % text)
        elif not _command_path_is_valid(cmd):
            bad.append("%r -> %r (path not in command tree)" % (text, cmd))
    assert not bad, "Invalid command paths:\n  " + "\n  ".join(bad)


def test_demo_inputs_all_translate_and_validate():
    for text in nl2lldb.DEMO_INPUTS:
        t = T.translate(text)
        assert t.command, "demo input did not translate: %r" % text
        assert _command_path_is_valid(t.command), \
            "demo command invalid: %r -> %r" % (text, t.command)


# ---------------------------------------------------------------------------
# 3. Extraction unit tests.
# ---------------------------------------------------------------------------
def test_extract_file_and_line():
    ex = extract("break at foo.c:42")
    assert ex.file == "foo.c" and ex.line == 42


def test_extract_line_of_file():
    ex = extract("break at line 88 of parser.cpp")
    assert ex.file == "parser.cpp" and ex.line == 88


def test_extract_hex_address():
    ex = extract("read memory at 0x7fff5fbff8c0")
    assert ex.hex_addrs == ["0x7fff5fbff8c0"]


def test_extract_pid():
    assert extract("attach to pid 4242").pid == 4242


def test_extract_function_name_skips_prepositions():
    assert extract("set a breakpoint at main").func == "main"
    assert extract("break in handle_request").func == "handle_request"


def test_extract_condition():
    ex = extract("set a breakpoint at foo if x == 5")
    assert ex.condition == "x == 5"


def test_extract_byte_count():
    ex = extract("read 32 bytes of memory at 0x10")
    assert ex.byte_count == 32


def test_extract_one_shot_and_entry():
    assert extract("set a temporary breakpoint at main").one_shot is True
    assert extract("run and stop at the entry point").stop_at_entry is True


def test_extract_register_with_dollar():
    assert extract("read register $rax").reg == "rax"


def test_extract_setting():
    ex = extract("set setting target.run-args to --debug")
    assert ex.setting_name == "target.run-args"
    assert ex.setting_value == "--debug"


# ---------------------------------------------------------------------------
# 4. Validator behaviour: alias expansion, sub-command suggestions.
# ---------------------------------------------------------------------------
def test_validator_accepts_canonical_commands():
    v = Validator(BACKEND)
    for cmd in ["breakpoint set", "thread step-over", "target modules lookup",
                "watchpoint set variable", "process attach", "register read"]:
        assert v.analyze(cmd)["valid"], "should be valid: %r" % cmd


def test_validator_expands_aliases():
    v = Validator(BACKEND)
    # 'b' is an alias for 'breakpoint set', 'bt' for 'thread backtrace'.
    assert v.command_path("b main")[0] == ["breakpoint", "set"]
    assert v.command_path("bt")[0] == ["thread", "backtrace"]


def test_validator_suggests_subcommands_for_bare_parent():
    v = Validator(BACKEND)
    info = v.analyze("breakpoint")
    # 'breakpoint' alone needs a sub-command; suggestions should include real ones.
    assert info["valid"]  # 'breakpoint' itself exists as a command node
    assert "set" in BACKEND.subcommands(["breakpoint"])


def test_validator_flags_unknown_command():
    v = Validator(BACKEND)
    info = v.analyze("breakpiont set")  # typo
    assert not info["valid"]
    assert "breakpoint" in info["suggestions"]


def test_unrecognized_input_returns_suggestions():
    t = T.translate("frobnicate the doohickey")
    assert t.command is None
    assert t.suggestions  # fallback offers something


# ---------------------------------------------------------------------------
# 5. Command-tree sanity.
# ---------------------------------------------------------------------------
def test_core_top_level_commands_present():
    for cmd in ["breakpoint", "watchpoint", "thread", "frame", "process",
                "target", "memory", "register", "expression", "disassemble",
                "settings", "source", "help", "apropos", "version", "quit", "gui"]:
        assert cmd in COMMAND_TREE, "missing top-level command: %s" % cmd


def test_known_subcommands_present():
    assert "set" in COMMAND_TREE["breakpoint"]
    assert "step-inst-over" in COMMAND_TREE["thread"]
    assert "lookup" in COMMAND_TREE["target"]["modules"]
    assert "variable" in COMMAND_TREE["watchpoint"]["set"]


# ---------------------------------------------------------------------------
# 6. Performance: a single translator should sustain high throughput.
# ---------------------------------------------------------------------------
def test_performance_throughput():
    # Measure the *uncached* path so this guards against real parser
    # regressions (O(n^2), accidental recompilation) rather than cache hits.
    raw = make_translator(force_static=True, cache_size=0)
    sample = [text for text, _ in EXACT_CASES]
    iterations = 4000
    n = 0
    start = time.perf_counter()
    for i in range(iterations):
        raw.translate(sample[i % len(sample)])
        n += 1
    elapsed = time.perf_counter() - start
    rate = n / elapsed
    # Conservative floor so the test is not flaky on slow CI; real rate is much
    # higher.  Mostly this guards against accidental O(n^2)/recompilation regressions.
    assert rate > 1000, "throughput too low: %.0f translations/sec" % rate
    return rate


# ---------------------------------------------------------------------------
# 7. Suggestions for partial input and incomplete commands.
# ---------------------------------------------------------------------------
def _t(text):
    return T.translate(text)


def test_group_only_input_suggests_subcommands():
    for word, expect_sub in [("breakpoint", "breakpoint set"),
                             ("thread", "thread step-over"),
                             ("watchpoint", "watchpoint set"),
                             ("the breakpoint", "breakpoint list"),
                             ("memory", "memory read")]:
        t = _t(word)
        assert t.command is None, "%r should not produce a command" % word
        assert t.complete is False
        assert t.suggestions, "%r should offer suggestions" % word
        assert expect_sub in t.suggestions, \
            "%r suggestions should include %r, got %s" % (word, expect_sub, t.suggestions)


def test_partial_breakpoint_set_suggests_locations():
    t = _t("set a breakpoint")
    assert t.command == "breakpoint set"
    assert t.complete is False
    assert any(s.startswith("breakpoint set --name") for s in t.suggestions)
    assert any("--file" in s for s in t.suggestions)


def test_incomplete_attach_suggests_pid_or_name():
    t = _t("attach")
    assert t.complete is False
    assert any("--pid" in s for s in t.suggestions)
    assert any("--name" in s for s in t.suggestions)


def test_incomplete_frame_select_suggests_index():
    t = _t("select frame")
    assert t.command == "frame select"
    assert t.complete is False
    assert any("frame select <" in s for s in t.suggestions)


def test_incomplete_memory_read_suggests_address():
    t = _t("read some memory")
    assert t.command == "memory read"
    assert t.complete is False
    assert any("memory read <0x" in s for s in t.suggestions)


def test_incomplete_watchpoint_suggests_variable():
    t = _t("set a watchpoint")
    assert t.complete is False
    assert any("watchpoint set variable" in s for s in t.suggestions)


def test_incomplete_settings_set_suggests_usage():
    t = _t("change a setting")
    assert t.complete is False
    assert any("settings set <" in s for s in t.suggestions)


def test_incomplete_expression_suggests_usage():
    t = _t("evaluate")
    assert t.complete is False
    assert any(s.startswith("expression --") for s in t.suggestions)


def test_unrecognized_input_offers_suggestions():
    t = _t("frobnicate the doohickey")
    assert t.command is None
    assert t.complete is False
    assert t.suggestions


def test_complete_commands_are_marked_complete_without_suggestions():
    for text in ["step over", "continue", "show a backtrace", "list breakpoints",
                 "read register rax", "set a breakpoint at main", "quit"]:
        t = _t(text)
        assert t.command, "%r should translate" % text
        assert t.complete is True, "%r should be complete" % text
        assert t.suggestions == [], "%r should have no suggestions, got %s" % (text, t.suggestions)


# ---------------------------------------------------------------------------
# 8. lru_cache behaviour.
# ---------------------------------------------------------------------------
def test_translation_cache_returns_identical_object():
    c = make_translator(force_static=True, cache_size=128)
    a = c.translate("step over")
    b = c.translate("step over")
    assert a is b, "repeated translation should return the cached object"
    info = c.cache_info()
    assert info is not None and info.hits >= 1


def test_cache_can_be_disabled():
    nc = make_translator(force_static=True, cache_size=0)
    a = nc.translate("continue")
    b = nc.translate("continue")
    assert a == b           # same value
    assert a is not b       # but recomputed each time
    assert nc.cache_info() is None


def test_cache_clear_resets_stats():
    c = make_translator(force_static=True, cache_size=128)
    c.translate("backtrace")
    c.translate("backtrace")
    assert c.cache_info().currsize >= 1
    c.cache_clear()
    assert c.cache_info().currsize == 0


def test_cache_does_not_change_results():
    cached = make_translator(force_static=True, cache_size=256)
    uncached = make_translator(force_static=True, cache_size=0)
    for text, _ in EXACT_CASES:
        assert cached.translate(text).command == uncached.translate(text).command


def test_backend_subcommands_returns_safe_copy():
    b = StaticBackend()
    first = b.subcommands(["breakpoint"])
    first.append("BOGUS")              # mutate the returned list
    second = b.subcommands(["breakpoint"])
    assert "BOGUS" not in second, "cached value must not be mutated by callers"


def test_backend_cache_speeds_up_repeat_lookups():
    b = StaticBackend()
    path = ["target", "modules", "lookup"]
    reps = 20000
    t0 = time.perf_counter()
    for _ in range(reps):
        b.command_exists(path)
    warm = time.perf_counter() - t0
    assert warm < 1.0, "cached lookups too slow: %.3fs for %d calls" % (warm, reps)


# ---------------------------------------------------------------------------
# 9. Order-independent (n-gram / bag-of-words) matching.
# ---------------------------------------------------------------------------
_BY_NAME = {it.name: it for it in nl2lldb.INTENTS}


def _toks(text: str):
    return nl2lldb._ngram_tokens(nl2lldb.extract(text).tokens)


def test_scrambled_inputs_map_to_correct_command():
    """Words supplied out of order still produce the right command."""
    cases = {
        "main breakpoint set": "breakpoint set --name main",
        "at main set breakpoint": "breakpoint set --name main",
        "0x400500 breakpoint at set": "breakpoint set --address 0x400500",
        "breakpoints list all": "breakpoint list",
        "2 breakpoint delete": "breakpoint delete 2",
        "program the run": "process launch",
        "going keep": "process continue",
        "over step": "thread step-over",
        "in step": "thread step-in",
        "out step": "thread step-out",
        "threads list": "thread list",
        "variables local show": "frame variable",
        "rax register read": "register read rax",
        "registers all read": "register read --all",
        "0x1000 at memory read": "memory read 0x1000",
        "counter variable the watch": "watchpoint set variable counter",
        "watchpoints list": "watchpoint list",
        "1 watchpoint delete": "watchpoint delete 1",
        "main disassemble": "disassemble --name main",
        "1234 pid to attach": "process attach --pid 1234",
        "modules loaded list": "target modules list",
        "malloc symbol look up": "target modules lookup --name malloc",
        "result print": "expression -- result",
        "self po": "expression -O -- self",
    }
    for text, expected in cases.items():
        assert tr(text) == expected, "%r -> %r (expected %r)" % (text, tr(text), expected)


def test_scrambling_preserves_in_order_result():
    """Permuting the words of a correct in-order request keeps the command."""
    import itertools
    samples = [
        ("set a breakpoint at main", "breakpoint set --name main"),
        ("list all breakpoints", "breakpoint list"),
        ("read register rax", "register read rax"),
        ("watch variable counter", "watchpoint set variable counter"),
    ]
    for text, expected in samples:
        words = text.split()
        for perm in itertools.permutations(words):
            got = tr(" ".join(perm))
            assert got == expected, "perm %r -> %r (expected %r)" % (perm, got, expected)


def test_ngram_score_is_order_independent():
    """ngram_score depends only on the set of words, not their order."""
    bp = _BY_NAME["breakpoint_set"]
    a = bp.ngram_score(_toks("set a breakpoint"))
    b = bp.ngram_score(_toks("breakpoint a set"))
    assert a == b > 0


def test_ngram_score_rewards_discriminative_words():
    """A list request scores higher for the *_list intent than the *_set one."""
    toks = _toks("watchpoints list")
    assert _BY_NAME["watchpoint_list"].ngram_score(toks) > 0
    assert (_BY_NAME["watchpoint_list"].ngram_score(toks)
            > _BY_NAME["watchpoint_set"].ngram_score(toks))


def test_strong_ordered_phrase_still_wins():
    """An in-order multi-word phrase is trusted over the n-gram tie-break."""
    # 'backtrace all threads' must remain a backtrace, not a thread list.
    assert tr("backtrace all threads") == "thread backtrace --all"
    assert tr("step over") == "thread step-over"
    assert tr("next instruction") == "thread step-inst-over"


# ---- the regex -> slots compiler -----------------------------------------
def _slots_as_sets(pattern):
    return [([set(a) for a in alts], opt)
            for alts, opt in nl2lldb._compile_signal(pattern)]


def test_compiler_sequence_is_and():
    # "step over" -> two required slots (AND).
    assert _slots_as_sets(r"\bstep\s+over\b") == [([{"step"}], False), ([{"over"}], False)]


def test_compiler_alternation_is_or():
    slots = _slots_as_sets(r"\b(?:list|show|display|see)\b")
    assert len(slots) == 1
    alts, optional = slots[0]
    assert {"list"} in alts and {"show"} in alts and {"see"} in alts
    assert optional is False


def test_compiler_optional_group():
    # (?:the\s+)? is optional and contributes no required slot.
    slots = _slots_as_sets(r"\bshow\s+(?:the\s+)?source\b")
    # 'the' is a stopword so the optional group yields no alternatives; the
    # required slots are just {show} and {source}.
    assert ([{"show"}], False) in slots and ([{"source"}], False) in slots


def test_compiler_join_space_optional():
    # watch\s*point should match BOTH 'watch point' and 'watchpoint'.
    slots = _slots_as_sets(r"\bwatch\s*points?\b")
    assert len(slots) == 1
    alts, _ = slots[0]
    assert {"watch", "point"} in alts and {"watchpoint"} in alts


def test_compiler_multiword_alternative():
    # (?:po|print object) -> one slot, alternatives {po} OR {print, object}.
    slots = _slots_as_sets(r"\b(?:po|print\s+object)\b")
    assert len(slots) == 1
    alts, _ = slots[0]
    assert {"po"} in alts and {"print", "object"} in alts


def test_idf_suppresses_generic_words():
    """Common verbs are less discriminative than rare command words."""
    idf = nl2lldb._IDF
    assert idf["disassemble"] >= idf["set"]
    assert idf["watchpoint"] >= idf["list"]


# ---- normalisation + loose identifier ------------------------------------
def test_stem_normalises_plurals():
    assert nl2lldb._stem("breakpoints") == "breakpoint"
    assert nl2lldb._stem("registers") == "register"
    assert nl2lldb._stem("process") == "process"   # kept (exception)


def test_ngram_tokens_drops_fillers_and_lowercases():
    toks = _toks("Set a BreakPoint")
    assert "set" in toks and "breakpoint" in toks
    assert "a" not in toks


def test_loose_identifier_skips_command_vocabulary():
    # 'breakpoint' and 'set' are command words; 'main' is the real symbol.
    assert nl2lldb._loose_identifier(["main", "breakpoint", "set"]) == "main"
    # nothing but command words -> no identifier.
    assert nl2lldb._loose_identifier(["list", "all", "breakpoints"]) is None
    # numbers / addresses are never identifiers.
    assert nl2lldb._loose_identifier(["0x4005f0", "at", "break"]) is None


def test_scrambled_does_not_break_caching():
    t = make_translator(force_static=True, cache_size=128)
    a = t.translate("main breakpoint set")
    b = t.translate("main breakpoint set")
    assert a is b
    info = t.cache_info()
    assert info is not None and info.hits >= 1


def test_ngram_weight_zero_recovers_pure_ordered():
    """With ngram_weight=0 the scrambled rescue is disabled (sanity check that
    the n-gram layer is what resolves out-of-order input)."""
    plain = make_translator(force_static=True, ngram_weight=0.0)
    # In-order still fine.
    assert (plain.translate("set a breakpoint at main").command
            == "breakpoint set --name main")
    # Pure scramble is no longer guaranteed to resolve to the same command,
    # whereas the default translator (ngram_weight>0) does.
    assert tr("main breakpoint set") == "breakpoint set --name main"


# ---------------------------------------------------------------------------
# 10. Suggestions are always offered when a valid+complete command can't form.
# ---------------------------------------------------------------------------
def _always_suggests(text: str):
    r = T.translate(text)
    formed = bool(r.command) and r.valid and r.complete
    if not formed:
        assert r.suggestions, "no suggestions for %r" % text
    return r


def test_empty_input_offers_top_level_commands():
    r = T.translate("")
    assert not r.command and not r.complete
    assert r.suggestions, "empty input should still suggest commands"
    # The suggestions should be real top-level commands.
    assert "breakpoint" in r.suggestions


def test_whitespace_input_offers_suggestions():
    assert T.translate("    ").suggestions


def test_gibberish_offers_suggestions():
    for text in ["frobnicate the doohickey", "xyzzy plugh", "asdf qwer zxcv"]:
        r = _always_suggests(text)
        assert r.command is None
        assert r.suggestions


def test_incomplete_commands_offer_completions():
    """Recognised-but-underspecified requests yield the partial command AND
    suggestions describing how to complete it."""
    cases = [
        "set a breakpoint",          # no location
        "read memory",               # no address
        "attach to the process",     # no pid/name
        "write to register",         # no register/value
        "watch",                     # no variable
    ]
    for text in cases:
        r = T.translate(text)
        assert not r.complete, "%r should be incomplete" % text
        assert r.suggestions, "%r should carry completion suggestions" % text


def test_command_group_offers_subcommands():
    for group in ["breakpoint", "thread", "watchpoint", "target"]:
        r = T.translate(group)
        assert not r.complete and r.suggestions
        # Every suggestion is that group's sub-command.
        assert all(s.startswith(group + " ") for s in r.suggestions)


def test_unknown_action_on_known_group_still_safe():
    # A recognised group word with an unknown verb resolves to *some* valid
    # command or, failing that, offers suggestions -- never a dead end.
    r = T.translate("frobnicate the breakpoints")
    assert (r.command and r.valid and r.complete) or r.suggestions


def test_valid_complete_commands_have_no_noise_suggestions():
    """A cleanly translated command should not be cluttered with suggestions."""
    clean = ["continue", "step over", "list breakpoints", "backtrace",
             "read register rax", "set a breakpoint at main"]
    for text in clean:
        r = T.translate(text)
        assert r.command and r.valid and r.complete
        assert r.suggestions == [], "%r should have no suggestions, got %r" % (text, r.suggestions)


def test_suggestion_invariant_over_many_inputs():
    """Across a broad mix, anything short of a valid+complete command must come
    with at least one suggestion."""
    mix = [
        "", "   ", "help", "do the thing", "breakpoint", "watch", "memory",
        "set a breakpoint", "read memory", "attach", "frobnicate widgets",
        "thread", "register", "disassemble", "po", "settings",
    ]
    for text in mix:
        _always_suggests(text)


# ---------------------------------------------------------------------------
# Minimal built-in test runner (used when not running under pytest).
# ---------------------------------------------------------------------------
def _run() -> int:
    tests = [(name, obj) for name, obj in sorted(globals().items())
             if name.startswith("test_") and callable(obj)]
    passed = failed = 0
    failures = []
    for name, fn in tests:
        try:
            result = fn()
            extra = ""
            if name == "test_performance_throughput" and isinstance(result, float):
                extra = "  (%.0f translations/sec)" % result
            print("PASS  %s%s" % (name, extra))
            passed += 1
        except AssertionError as e:
            print("FAIL  %s" % name)
            failures.append((name, str(e)))
            failed += 1
        except Exception:
            print("ERROR %s" % name)
            failures.append((name, traceback.format_exc()))
            failed += 1

    print("\n%d passed, %d failed (%d total)" % (passed, failed, passed + failed))
    if failures:
        print("\n" + "=" * 70)
        for name, msg in failures:
            print("\n[%s]\n%s" % (name, msg))
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(_run())
